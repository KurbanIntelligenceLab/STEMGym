# Reference implementation

This snapshot contains the runtime and evaluator for the 220-episode reference study. `reference/reproducibility/verification.json` records the runtime versions, and `release_manifest.json` pins the data and checkpoint hashes.

Create a Python environment matching the recorded versions, install the package, and provide the pinned worlds under `data/simulated/` and the three analyst checkpoints under `checkpoints/`. From the extracted repository root, run:

```sh
python reference/reproducibility/evaluate_reference.py --output results/reference.json
```

The evaluator is byte-identical to the file identified by the stored result hash. Runtime changes in this snapshot are limited to documentation. `SOURCE_MANIFEST.json` records the distributed file hashes. Use the main repository's reproduction tools to verify results and generate figures and tables.
