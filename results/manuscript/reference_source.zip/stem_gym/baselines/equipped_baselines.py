"""Assemble findings from the manuscript reference analyst."""
from __future__ import annotations
from typing import Any
import numpy as np
from stem_gym.agents.analyst import Analyst


def _assemble_findings(
    analyst: Analyst,
    grid_shape: tuple[int, int],
) -> dict[str, Any]:
    """Build findings dict from analyst state and corrected phase labels.

    Used by the synchronous manuscript reference evaluator.
    """
    # Phase map from corrected tile phases (Cohen's d significance test)
    phase_map = None
    corrected = analyst.get_corrected_tile_phases()
    if corrected is not None:
        gh, gw = grid_shape
        phase_map = np.zeros((gh, gw), dtype=np.int32)
        for (r, c), phase in corrected.items():
            if 0 <= r < gh and 0 <= c < gw:
                phase_map[r, c] = phase

    # Defect positions from analyst accumulated state
    defect_positions = []
    all_positions = analyst._all_atom_positions_nm
    all_labels = analyst._all_defect_labels

    if all_positions and all_labels:
        offset = 0
        for tile_pos in all_positions:
            n = len(tile_pos)
            for j in range(n):
                label_idx = offset + j
                if label_idx < len(all_labels):
                    lbl = all_labels[label_idx]
                    if lbl != "pristine":
                        defect_positions.append({
                            "position": (float(tile_pos[j, 0]), float(tile_pos[j, 1])),
                            "type": lbl,
                        })
            offset += n

    # Atom positions
    atom_positions = None
    if all_positions:
        atom_positions = np.concatenate(all_positions, axis=0)

    return {
        "defect_census": analyst.get_defect_census(),
        "defect_positions": defect_positions,
        "phase_map": phase_map,
        "atom_positions": atom_positions,
    }
