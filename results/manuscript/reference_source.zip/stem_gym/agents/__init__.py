"""Agent implementations for STEMGym."""
