"""Fetch and verify the two small software-test fixtures at their expected paths."""
from pathlib import Path
import hashlib,json,urllib.request
HERE=Path(__file__).resolve().parent
ROOT=HERE.parents[1]
manifest=json.loads((HERE/'release_manifest.json').read_text())
for name,directory in [('test_world.h5','simulated'),('replay_world.h5','replay')]:
    record=next(r for r in manifest['siblings'] if r['rfilename']=='worlds/'+name)
    path=ROOT/'data'/directory/name
    path.parent.mkdir(parents=True,exist_ok=True)
    if not path.exists():
        url=f"https://huggingface.co/datasets/{manifest['id']}/resolve/{manifest['sha']}/worlds/{name}"
        partial=path.with_suffix('.download')
        urllib.request.urlretrieve(url,partial)
        assert hashlib.sha256(partial.read_bytes()).hexdigest()==record['lfs']['sha256']
        partial.replace(path)
    assert hashlib.sha256(path.read_bytes()).hexdigest()==record['lfs']['sha256']
    print(f'{directory}/{name}: matches pinned release')
