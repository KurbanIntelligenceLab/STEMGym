"""Package the manuscript and reproducible source; exclude data and local secrets."""
from pathlib import Path
import hashlib
import json
import zipfile

ROOT = Path(__file__).resolve().parents[2]
OUT = ROOT / "mlst_manuscript/stemgym_mlst_source.zip"
files = [ROOT / name for name in ["README.md", "LICENSE", "pyproject.toml"]]
for directory in ["stem_gym", "tests"]:
    files += [p for p in (ROOT / directory).rglob("*") if p.is_file() and p.suffix in {".py", ".yaml", ".yml"} and "__pycache__" not in p.parts]
manuscript = ROOT / "mlst_manuscript"
files += [p for p in manuscript.iterdir() if p.suffix in {".tex", ".bib", ".cls", ".sty", ".bst"} or p.name in {"figure1.pdf", "figure3.pdf"}]
files += [p for p in (manuscript / "reproducibility").iterdir() if p.suffix in {".py", ".json", ".md"}]
files = sorted(set(files))
assert all(p.exists() for p in files)
manifest = {str(p.relative_to(ROOT)): hashlib.sha256(p.read_bytes()).hexdigest() for p in files}
with zipfile.ZipFile(OUT, "w", compression=zipfile.ZIP_DEFLATED, compresslevel=6) as archive:
    for p in files:
        archive.write(p, str(p.relative_to(ROOT)))
    archive.writestr("SOURCE_MANIFEST.json", json.dumps(manifest, indent=2) + "\n")
with zipfile.ZipFile(OUT) as archive:
    assert archive.testzip() is None
    for name, digest in manifest.items():
        assert hashlib.sha256(archive.read(name)).hexdigest() == digest
print(f"{len(files)} files packaged and rechecked; {OUT.stat().st_size:,} bytes")
