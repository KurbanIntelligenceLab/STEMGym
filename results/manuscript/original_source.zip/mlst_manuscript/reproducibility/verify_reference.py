"""Independently verify a selected run and its generated tables and summary."""
from pathlib import Path
import argparse
import hashlib
import json
import numpy as np
from evaluate_reference import WORLDS, POLICIES

HERE = Path(__file__).resolve().parent


def verify(results_path, artifacts_dir):
    results = json.loads(results_path.read_text())
    assert results['protocol']['script_sha256'] == hashlib.sha256((HERE / 'evaluate_reference.py').read_bytes()).hexdigest()
    for field, value in {'dataset_revision': 'aa12b7380fed7a4362a18aa67df1ea135f7e15ff', 'seeds': 10, 'budget': 5000, 'dose_per_tile': 100, 'task': 'defect_census', 'score_every': 5, 'integration_checkpoints': 50}.items():
        assert results['protocol'][field] == value
    expected = {(w, p, s) for w in WORLDS for p in POLICIES for s in range(10)}
    expected |= {('batio3_interface_' + d, 'raster_trained', s) for d in ['medium', 'hard'] for s in range(10)}
    actual = {(e['world'], e['policy'], e['seed']) for e in results['episodes']}
    assert actual == expected and len(results['episodes']) == 220
    for e in results['episodes']:
        assert len(e['tiles']) == len({tuple(t) for t in e['tiles']}) == e['analysed_tiles'] == 50
        assert e['dose_used'] == 5000
        log = e['score_log']
        assert [z['dose_used'] for z in log] == list(range(500, 5001, 500))
        x = np.linspace(0, 1, 50)
        scores = np.interp(x, np.array([z['dose_used'] for z in log]) / 5000,
                           [z['task_score'] for z in log], left=0, right=log[-1]['task_score'])
        assert np.all((scores >= 0) & (scores <= 1))
        assert np.array_equal(x, e['dec_dose_fractions']) and np.array_equal(scores, e['dec_scores'])
        # Explicit trapezoidal sum works with both NumPy 1.x and 2.x.
        area = np.sum(np.diff(x) * (scores[1:] + scores[:-1]) / 2)
        assert abs(float(area) - e['dec_auc']) < 1e-12
        assert scores[-1] == e['final_score']
    summary = json.loads((artifacts_dir / 'reproducibility/reference_summary.json').read_text())
    assert set(summary) == set(WORLDS)
    table = (artifacts_dir / 'sec_experiments.tex').read_text()
    for w in WORLDS:
        assert set(summary[w]) == set(POLICIES)
        for p in POLICIES:
            stats = summary[w][p]
            v = np.array([e['dec_auc'] for e in results['episodes'] if e['world'] == w and e['policy'] == p])
            assert len(v) == 10
            assert abs(v.mean() - stats['mean']) < 1e-12
            assert abs(v.std(ddof=1) - stats['sample_sd']) < 1e-12
    labels = ['Raster + heuristic', 'Raster + trained', 'Random + trained', 'GP intensity + trained', 'GP defects + trained']
    for p, label in zip(POLICIES, labels):
        cells = [f"${summary[w][p]['mean']:.3f} \\pm {summary[w][p]['sample_sd']:.3f}$" for w in WORLDS]
        assert label + ' & ' + ' & '.join(cells) + r' \\' in table
    return {'episodes': 220, 'all_expected_configurations_and_seeds': True,
            'all_unique_50_acquisitions': True, 'all_curves_and_integrals_recomputed': True,
            'table_values_recomputed': True,
            'results_sha256': hashlib.sha256(results_path.read_bytes()).hexdigest()}


def main():
    parser = argparse.ArgumentParser(description=__doc__)
    parser.add_argument('--results', type=Path, default=HERE / 'reference_results.json')
    parser.add_argument('--artifacts-dir', type=Path, default=HERE.parent)
    parser.add_argument('--report', type=Path, help='Optional JSON destination for this verification only')
    args = parser.parse_args()
    checks = verify(args.results, args.artifacts_dir)
    if args.report:
        args.report.parent.mkdir(parents=True, exist_ok=True)
        args.report.write_text(json.dumps(checks, indent=2) + '\n')
    print('220 episodes: complete configurations, unique acquisitions, curves, integrals and table values verified.')


if __name__ == '__main__':
    main()
