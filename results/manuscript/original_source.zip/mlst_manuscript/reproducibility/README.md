# Manuscript reproduction

This repository contains the dataset manuscript, its supporting source, and the records needed to reproduce the reported reference protocol.

## Release status

The pinned public dataset revision is `aa12b7380fed7a4362a18aa67df1ea135f7e15ff` in [kurbanintelligencelab/stemgym](https://huggingface.co/datasets/kurbanintelligencelab/stemgym/tree/aa12b7380fed7a4362a18aa67df1ea135f7e15ff). The manifest contains the original file hashes. The 15 benchmark worlds have 16,800 tiles; 13 records pass coordinate-bounds checks and contain 13,600 tiles. The original hard SrTiO3 and Pt/C files are retained as additional records with inconsistent field metadata.

**Coordinate-bounds consistency is not physical validation.** The independent audit confirms the two field-bounds failures and identifies a broader sampling/registration concern in the stored images. SrTiO3 image periodicity disagrees with the declared calibration, and repeated zero-intensity bands occur in the release overviews despite all-valid region masks. The draft reports these findings explicitly. The reference results describe software behaviour on the current release and should be rerun after any data correction. No original HDF5 files have been recalibrated or overwritten.

## Reproduce

Run from the repository root with Python 3.10 or later:

```sh
pip install -e ".[dev]"
python mlst_manuscript/reproducibility/validate_release.py
python mlst_manuscript/reproducibility/audit_calibration.py
mkdir -p results/mlst_reference
python mlst_manuscript/reproducibility/evaluate_reference.py \
    --output results/mlst_reference/episodes.json
python mlst_manuscript/reproducibility/build_figures.py \
    --results results/mlst_reference/episodes.json \
    --output-dir results/mlst_reference
python mlst_manuscript/reproducibility/verify_reference.py \
    --results results/mlst_reference/episodes.json \
    --artifacts-dir results/mlst_reference
python mlst_manuscript/reproducibility/prepare_test_data.py
python -m pytest tests/test_env.py tests/test_metrics.py tests/test_replay.py
```

The validator downloads missing material worlds and the three analyst checkpoints from the pinned revision and verifies existing files without replacing them. The fixture script verifies and places the two small test/replay worlds in the locations expected by the tests. The reference evaluator defaults to four workers, ten seeds, 50 distinct acquisitions per episode and fresh analyst checkpoints. Analyst inference uses CPU; GP fitting selects CUDA when available. The supplied run used CPU throughout. On CUDA-equipped hosts, set `CUDA_VISIBLE_DEVICES=""` before evaluation to retain CPU computation. Its 200 primary episodes compare five configurations on four easy crystalline worlds; 20 additional episodes cover trained raster on the medium and hard BaTiO3 records. Sample standard deviations use `ddof=1`.

Use a previously unused results path for a new run. Repeating the command resumes the same file; the evaluator's default output is the completed supplied study and therefore has no pending episodes. The builder and verifier above consume the explicitly selected run. Derived figures, section sources with embedded tables, and `reproducibility/reference_summary.json` are saved under the chosen output directory. Tables live directly in `sec_experiments.tex` and `supplementary.tex`; the generator updates their marked table blocks while preserving the surrounding text. Both require the full ten-seed, 220-episode reference protocol. Only the two figures used in the article are generated.

To check the supplied results without rerunning inference:

```sh
python mlst_manuscript/reproducibility/verify_reference.py
```

The verifier reads the selected results and artifacts without changing them; `--report PATH` optionally saves a verification report. It uses an explicit trapezoidal sum compatible with the declared NumPy range, avoiding the NumPy 2.0-only [`trapezoid` API](https://numpy.org/doc/stable/reference/generated/numpy.trapezoid.html). The evaluator is unchanged so its saved script hash remains valid. Its resume guard checks that file and the seed count; the complete archive source is identified by `SOURCE_MANIFEST.json`. Use fresh results whenever imported code or data changes. Runtime versions are recorded in `verification.json`; its original repeatability checks apply to the supplied study.

The GP policies select six random tiles before their first fit, then use GP guidance from acquisition seven and refit every three acquisitions. Scoring occurs every five acquisitions. Counts-only heuristic output and counts-plus-positions trained output use different available branches of the same defect-census scorer. The reported comparison is therefore between complete pipelines.

The main and supplementary LaTeX sources use the supplied IOP class and bibliography style. The editor's standalone compiler may not resolve this multi-file project; its missing-class error does not establish a source error. No class or template substitution is required.

## Evidence files

| File | Content |
|---|---|
| `release_manifest.json` | Pinned public identity and file hashes |
| `release_validation.json` | File integrity, geometry, schema and coordinate-bounds checks |
| `calibration_audit.json` | Independently repeated bounds checks, lattice-period measurements and overview coverage |
| `reference_results.json` | Resumable per-episode output, visited cells and score trajectories |
| `reference_summary.json` | Table means and sample standard deviations computed from the episode records |
| `figure_sources.json` | Tile selections used in the image figure |
| `verification.json` | Runtime versions and completed verification results |

The archive contains the retained dataset and reference-evaluation code. Retired exploratory experiments, old results, and duplicate manuscript copies have been removed from the working repository.
