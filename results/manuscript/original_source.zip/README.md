# STEMGym

Source and reproducibility files for **STEMGym: Benchmarking Sequential Decision-Making under Dose Budgets in Autonomous Electron Microscopy**.

## Manuscript

- `mlst_manuscript/main.tex`: main article, with section sources in the same directory.
- `mlst_manuscript/supplement.tex`: supplementary material.
- `mlst_manuscript/stemgym_mlst_overleaf.zip`: manuscript-only Overleaf package.
- `mlst_manuscript/stemgym_mlst_source.zip`: manuscript and reproducible source package.
- [Reproduction instructions and evidence](mlst_manuscript/reproducibility/README.md).

## Installation

```sh
pip install -e ".[dev]"
```

Python 3.10 or later is required. Regenerating scattering simulations additionally requires the optional simulation dependencies:

```sh
pip install -e ".[sim]"
```

## Data and checkpoints

The public dataset is [kurbanintelligencelab/stemgym](https://huggingface.co/datasets/kurbanintelligencelab/stemgym). For the exact article revision, use the validator, which downloads missing material worlds and the three analyst checkpoints and checks their hashes:

```sh
python mlst_manuscript/reproducibility/validate_release.py
python mlst_manuscript/reproducibility/prepare_test_data.py
```

The release contains 15 material worlds. The manuscript's 13-world core passes coordinate-bounds checks; hard SrTiO3 and hard Pt/C remain as additional records with inconsistent field metadata. The stored images also have unresolved scan-sampling and registration findings documented in the manuscript and calibration audit. The two small test/replay worlds are retained as software fixtures.

The three reference checkpoints are `atom_finder.pt`, `defect_classifier.pt`, and `phase_identifier.pt`. The general downloader supports `--worlds`, `--checkpoints`, and `--test-only`; it reads the public repository's current revision. Use the validator above for manuscript reproduction.

## Reference evaluation

The article compares raster with a heuristic analyst, raster with the trained analyst, random sampling with the trained analyst, and intensity-guided and defect-guided GP-UCB with the trained analyst. Its synchronous evaluator analyses each acquired tile before recording the associated score.

To check the supplied 220 episodes and table values:

```sh
python mlst_manuscript/reproducibility/verify_reference.py
```

To run a fresh evaluation and generate its figures and tables separately:

```sh
mkdir -p results/mlst_reference
python mlst_manuscript/reproducibility/evaluate_reference.py \
    --output results/mlst_reference/episodes.json
python mlst_manuscript/reproducibility/build_figures.py \
    --results results/mlst_reference/episodes.json \
    --output-dir results/mlst_reference
python mlst_manuscript/reproducibility/verify_reference.py \
    --results results/mlst_reference/episodes.json \
    --artifacts-dir results/mlst_reference
```

The supplied reference run used CPU computation. On a CUDA-equipped host, set `CUDA_VISIBLE_DEVICES=""` to retain CPU computation. Full protocol details and checkpoint identities are in the supplementary material and reproduction records.

## Retained source

| Directory | Purpose |
|---|---|
| `stem_gym/envs/` | Gymnasium environment, world loading, and replay fixture support |
| `stem_gym/agents/` | Trained and heuristic analysts, model definitions, and GP-UCB acquisition |
| `stem_gym/baselines/` | Random, raster, and GP-UCB helpers and findings assembly |
| `stem_gym/tasks/` | Defect census, phase mapping, targeted characterisation, and particle census |
| `stem_gym/scripts/` | Data download, analyst training, and world generation |
| `mlst_manuscript/reproducibility/` | Published evaluator, results, validation, figure generation, and packaging |
| `data/` | Material worlds and software-test fixtures |
| `checkpoints/` | Three trained reference analysts |
| `tests/` | Tests for the retained environment, analysts, baselines, metrics, replay, and generators |

`stem_gym/runner.py` retains generic episode helpers for software tests and reuse. The article's results are defined by `mlst_manuscript/reproducibility/evaluate_reference.py`.

## Checks

```sh
python -m pytest tests/test_env.py tests/test_metrics.py tests/test_replay.py
```

The analyst and baseline tests are also retained. Generator integration tests require simulation dependencies and are marked `slow`.

## License

Code: MIT. Data: CC-BY-4.0.
